# Text Glitch animation (Clip-path, text-shadow and pseudo-elements)

A Pen created on CodePen.io. Original URL: [https://codepen.io/oscar-jite/pen/yLwoeLE](https://codepen.io/oscar-jite/pen/yLwoeLE).

