# Glitch Text Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisunderdown/pen/KzEEJQ](https://codepen.io/chrisunderdown/pen/KzEEJQ).

